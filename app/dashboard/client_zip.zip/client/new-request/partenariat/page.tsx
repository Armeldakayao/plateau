"use client"


import { PartenaritRequestForm } from "@/components/dashboard/partenariat-form"
import Sidebar from "@/components/sidebar"
import { useCreatePartenaritRequest } from "@/hooks/services-requests/use-create-service-request"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export default function PartenaritRequestPage() {
  const router = useRouter()
  const createPartenaritRequest = useCreatePartenaritRequest()

  const handleSubmit = async (data: any) => {
    try {
      await createPartenaritRequest.mutateAsync(data)
      toast.success("Votre demande de partenariat a été envoyée avec succès!")
      router.push("/client/requests")
    } catch (error) {
      toast.error("Une erreur est survenue lors de l'envoi de votre demande.")
      console.error("Error creating partnership request:", error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
            <Sidebar/>
         <div className="ml-72">
            <PartenaritRequestForm onSubmit={handleSubmit} isLoading={createPartenaritRequest.isPending} />
         </div>
        </div>
   
  )
}
