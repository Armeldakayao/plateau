"use client"


import { RdvRequestForm } from "@/components/dashboard/rdv-form"
import Sidebar from "@/components/sidebar"
import { useCreateRdvRequest } from "@/hooks/services-requests/use-create-service-request"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"


export default function RdvRequestPage() {
  const router = useRouter()
  const createRdvRequest = useCreateRdvRequest()
const {toast} = useToast()
  const handleSubmit = async (data: any) => {
    try {
      await createRdvRequest.mutateAsync(data)
      toast({
        title: "Demande envoyée",
        description: "Votre demande de rendez-vous a bien été envoyée.",
      })
      router.push("/dashboard/client/mes-demandes")
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'envoi de la demande.",
        variant: "destructive",
      })
      console.error("Error creating RDV request:", error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
        <Sidebar/>
     <div className="ml-72">
         <RdvRequestForm onSubmit={handleSubmit} isLoading={createRdvRequest.isPending} />
     </div>
    </div>
  )
}
