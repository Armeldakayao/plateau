"use client"


import { MariageRequestForm } from "@/components/dashboard/mariage-form"
import Sidebar from "@/components/sidebar"
import { useCreateMariageRequest } from "@/hooks/services-requests/use-create-service-request"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export default function MariageRequestPage() {
  const router = useRouter()
  const createMariageRequest = useCreateMariageRequest()

  const handleSubmit = async (data: any) => {
    try {
      await createMariageRequest.mutateAsync(data)
      toast.success("Votre demande de mariage a été envoyée avec succès!")
      router.push("/client/requests")
    } catch (error) {
      toast.error("Une erreur est survenue lors de l'envoi de votre demande.")
      console.error("Error creating marriage request:", error)
    }
  }

  return (
     <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
                <Sidebar/>
             <div className="ml-72">
                <MariageRequestForm onSubmit={handleSubmit} isLoading={createMariageRequest.isPending} />
             </div>
            </div>
   
  )
}
