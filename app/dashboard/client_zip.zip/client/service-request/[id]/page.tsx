"use client"

import { useState } from "react"
import { useParams } from "next/navigation"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

import {
  ArrowLeft,
  Calendar,
  Clock,
  Download,
  FileText,
  Mail,
  Phone,
  Plus,
  Settings,
  Trash2,
  Upload,
  User,
  Eye,
  ExternalLink,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { fr } from "date-fns/locale"
import { useServiceRequest } from "@/hooks/services-requests/use-service-request"
import { useDeleteServiceRequest } from "@/hooks"
import { CreateTreatmentDialog } from "@/components/dashboard/create-treatment-dialog"
import { DeleteConfirmationDialog } from "@/components/dashboard/delete-confirmation-modal"
import { ServiceRequestDocumentUpload } from "@/components/dashboard/service-request-document-upload"
import { DocumentIcon } from "@/components/dashboard/document-icon"
import Sidebar from "@/components/sidebar"

const ETAT_OPTIONS = [
  { value: "en_attente", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "en_cours", label: "En cours", color: "bg-blue-100 text-blue-800" },
  { value: "termine", label: "Terminé", color: "bg-green-100 text-green-800" },
  { value: "annule", label: "Annulé", color: "bg-red-100 text-red-800" },
]

export default function ServiceRequestDetailPage() {
  const params = useParams()
  const router = useRouter()
  const requestId = params.id as string

  const [showUploadDialog, setShowUploadDialog] = useState(false)
  const [showTreatmentDialog, setShowTreatmentDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [uploadMode, setUploadMode] = useState<"request" | "treatment" | "general">("request")

  const { data: serviceRequest, isLoading } = useServiceRequest(requestId)
  const deleteRequest = useDeleteServiceRequest()

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    )
  }

  if (!serviceRequest) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Demande non trouvée</p>
        </div>
      </div>
    )
  }

  const getEtatBadge = (etat: string) => {
    const option = ETAT_OPTIONS.find((opt) => opt.value === etat)
    return <Badge className={option?.color || "bg-gray-100 text-gray-800"}>{option?.label || etat}</Badge>
  }

  const handleDelete = async () => {
    try {
      await deleteRequest.mutateAsync(requestId)
      router.push("/user/service-requests?success=request-deleted")
    } catch (error) {
      console.error("Erreur lors de la suppression:", error)
    }
  }

  const handleDownload = (doc: any) => {
    // Créer un lien de téléchargement et le déclencher
    const link = document.createElement('a')
    link.href = doc.url || doc.fileUrl || '#'
    link.download = doc.fileName || 'document'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    console.log("Downloading document:", doc.fileName)
  }

  const handlePreview = (doc: any) => {
    // Ouvrir le document dans un nouvel onglet pour prévisualisation
    if (doc.url || doc.fileUrl) {
      window.open(doc.url || doc.fileUrl, '_blank')
    }
  }

  const existingTreatment = serviceRequest.traitements?.[0]

  // Fonction pour afficher les détails de la demande de manière structurée
  const renderRequestDetails = (demande: any) => {
    if (typeof demande === 'string') {
      return (
        <div className="prose prose-sm max-w-none">
          <p className="whitespace-pre-wrap">{demande}</p>
        </div>
      )
    }

    if (typeof demande === 'object' && demande !== null) {
      return (
        <div className="space-y-4">
          {Object.entries(demande).map(([key, value]) => (
            <div key={key} className="border-l-2 border-primary/20 pl-4">
              <p className="text-sm font-medium text-muted-foreground capitalize">
                {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
              </p>
              <p className="font-medium mt-1">
                {typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value)}
              </p>
            </div>
          ))}
        </div>
      )
    }

    return (
      <div className="text-center py-8 text-muted-foreground">
        Aucun détail disponible
      </div>
    )
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
   <div>
    <Sidebar/>
     <div className="ml-72 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/user/service-requests">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Détails de la Demande</h1>
            <p className="text-muted-foreground">Référence: {serviceRequest.numeroReference}</p>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              setUploadMode("general")
              setShowUploadDialog(true)
            }}
          >
            <Upload className="h-4 w-4 mr-2" />
            Ajouter Document
          </Button>
          <Button variant="destructive" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="h-4 w-4 mr-2" />
            Supprimer
          </Button>
        </div>
      </div>

      {/* Status Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">{serviceRequest.type.toUpperCase()}</CardTitle>
                <CardDescription>
                  Créée le {format(new Date(serviceRequest.createdAt), "dd MMMM yyyy", { locale: fr })}
                </CardDescription>
              </div>
            </div>
            {getEtatBadge(serviceRequest.etat)}
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="details" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="details">Détails</TabsTrigger>
          <TabsTrigger value="documents">Documents ({serviceRequest.documents?.length || 0})</TabsTrigger>
          <TabsTrigger value="treatments">Traitements ({serviceRequest.traitements?.length || 0})</TabsTrigger>
          <TabsTrigger value="timeline">Historique</TabsTrigger>
        </TabsList>

        {/* Details Tab */}
        <TabsContent value="details" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Informations générales */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Informations Générales
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Type</p>
                    <p className="font-medium">{serviceRequest.type}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">État</p>
                    {getEtatBadge(serviceRequest.etat)}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Priorité</p>
                    <Badge variant={serviceRequest.priorite === "urgente" ? "destructive" : "secondary"}>
                      {serviceRequest.priorite}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Date limite</p>
                    <p className="font-medium">
                      {format(new Date(serviceRequest.dateLimiteTraitement), "dd/MM/yyyy", { locale: fr })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informations du demandeur */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Demandeur
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Nom complet</p>
                  <p className="font-medium">
                    {serviceRequest.nom} {serviceRequest.prenom}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <p>{serviceRequest.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <p>{serviceRequest.telephone}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Détails de la demande */}
          <Card>
            <CardHeader>
              <CardTitle>Détails de la Demande</CardTitle>
            </CardHeader>
            <CardContent>
              {renderRequestDetails(serviceRequest.demande)}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Documents ({serviceRequest.documents?.length || 0})</h3>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setUploadMode("request")
                  setShowUploadDialog(true)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Ajouter Document
              </Button>
              <Button asChild>
                <Link href={`/user/service-requests/${requestId}/documents`}>
                  <FileText className="h-4 w-4 mr-2" />
                  Voir Tous
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid gap-4">
            {serviceRequest.documents?.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Aucun document attaché</p>
                  <Button 
                    className="mt-4"
                    onClick={() => {
                      setUploadMode("request")
                      setShowUploadDialog(true)
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Ajouter votre premier document
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {serviceRequest.documents?.map((doc: any, index: number) => (
                  <Card key={index} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <DocumentIcon fileName={doc.fileName} mimeType={doc.mimeType} className="h-8 w-8 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate" title={doc.fileName}>
                            {doc.fileName}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {doc.fileSize ? formatFileSize(doc.fileSize) : "Taille inconnue"}
                          </p>
                          {doc.uploadedAt && (
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(doc.uploadedAt), "dd/MM/yyyy", { locale: fr })}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex gap-2 mt-4">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1"
                          onClick={() => handlePreview(doc)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          Voir
                        </Button>
                        <Button 
                          variant="default" 
                          size="sm" 
                          className="flex-1"
                          onClick={() => handleDownload(doc)}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Télécharger
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Treatments Tab */}
        <TabsContent value="treatments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Traitements ({serviceRequest.traitements?.length || 0})</h3>
            {!existingTreatment && (
              <Button onClick={() => setShowTreatmentDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Créer Traitement
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {serviceRequest.traitements?.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Clock className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Aucun traitement en cours</p>
                  <Button 
                    className="mt-4"
                    onClick={() => setShowTreatmentDialog(true)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Créer le premier traitement
                  </Button>
                </CardContent>
              </Card>
            ) : (
              serviceRequest.traitements?.map((treatment: any) => (
                <Card key={treatment.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Traitement #{treatment.numeroTraitement}</CardTitle>
                      <Badge variant={treatment.etat === "termine" ? "default" : "secondary"}>{treatment.etat}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Agent</p>
                        <p className="font-medium">
                          {treatment.agentPrenom} {treatment.agentNom}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Service</p>
                        <p className="font-medium">{treatment.agentService || "Non spécifié"}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Message</p>
                      <div className="bg-muted p-3 rounded-lg mt-1">
                        <p className="text-sm whitespace-pre-wrap">{treatment.messageAgent}</p>
                      </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Date d'échéance</p>
                        <p className="font-medium">
                          {format(new Date(treatment.dateEcheance), "dd/MM/yyyy HH:mm", { locale: fr })}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Temps estimé</p>
                        <p className="font-medium">{treatment.tempsEstime || 0}h</p>
                      </div>
                    </div>
                    
                    {/* Documents du traitement */}
                    {treatment.documents && treatment.documents.length > 0 && (
                      <div className="border-t pt-4">
                        <p className="text-sm font-medium text-muted-foreground mb-3">
                          Documents du traitement ({treatment.documents.length})
                        </p>
                        <div className="grid gap-2">
                          {treatment.documents.map((doc: any, docIndex: number) => (
                            <div key={docIndex} className="flex items-center justify-between p-2 bg-muted rounded">
                              <div className="flex items-center gap-2">
                                <DocumentIcon fileName={doc.fileName} mimeType={doc.mimeType} className="h-4 w-4" />
                                <span className="text-sm">{doc.fileName}</span>
                              </div>
                              <div className="flex gap-1">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handlePreview(doc)}
                                >
                                  <Eye className="h-3 w-3" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleDownload(doc)}
                                >
                                  <Download className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Timeline Tab */}
        <TabsContent value="timeline" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Historique de la Demande
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <div>
                    <p className="font-medium">Demande créée</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(serviceRequest.createdAt), "dd MMMM yyyy à HH:mm", { locale: fr })}
                    </p>
                  </div>
                </div>

                {serviceRequest.traitements?.map((treatment: any) => (
                  <div key={treatment.id} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div>
                      <p className="font-medium">
                        Traitement assigné à {treatment.agentPrenom} {treatment.agentNom}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(treatment.createdAt), "dd MMMM yyyy à HH:mm", { locale: fr })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <ServiceRequestDocumentUpload
        open={showUploadDialog}
        onOpenChange={setShowUploadDialog}
        serviceRequest={serviceRequest}
        mode={uploadMode}
      />

      <CreateTreatmentDialog
        open={showTreatmentDialog}
        onOpenChange={setShowTreatmentDialog}
        requestId={requestId}
        existingTreatment={existingTreatment}
      />

      <DeleteConfirmationDialog
        open={showDeleteDialog}
        onOpenChange={setShowDeleteDialog}
        onConfirm={handleDelete}
        title="Supprimer la demande"
        description="Êtes-vous sûr de vouloir supprimer cette demande ? Cette action est irréversible."
        isLoading={deleteRequest.isPending}
      />
    </div>
   </div>
  )
}